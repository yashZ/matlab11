t = cputime
global problem
s = sampleBeliefs(1000)
e = cputime-t
